import struct
import random

def char(c):
	return struct.pack("=c",c.encode('ascii'))
def word(c):
	return struct.pack("=h",c)
def dword(c):
	return struct.pack("=l",c)
def color(r,g,b):
	return bytes([b,g,r])

class Bitmap(object):
            
    def __init__(self, width,height):
	    self.width = width
	    self.height = height
	    self.framebuffer = []
	    self.clear()

    def clear(self):
	    self.framebuffer = [
	    [
		    color(0,0,0) 
			    for x in range(self.width)
		    ]
		
		    for y in range(self.height)
	    ]
        
    def write(self, filename):
	    f = open(filename, 'wb')

	    #file header
	    f.write(char('B'))
	    f.write(char('M'))
	    f.write(dword(14 + 40 + self.width * self.height *3))
	    f.write(dword(0))
	    f.write(dword(14+40))

	    #image header 40
	    f.write(dword(40))
	    f.write(dword(self.width))
	    f.write(dword(self.height))
	    f.write(word(1))
	    f.write(word(24))
	    f.write(dword(0))
	    f.write(dword(self.width * self.height *3))	
	    f.write(dword(0))
	    f.write(dword(0))
	    f.write(dword(0))
	    f.write(dword(0))

	    for x in range(self.height):
		    for y in range(self.width):
			    f.write(self.framebuffer[x][y])

	    f.close()
    def point(self,x,y,color):
        self.framebuffer[y][x] = color

    def line(self,x0,x1,y0,y1,color):
        
    
            y0,y1 = y1,y0
            
        b = y1 - m*x1
        for x in range(x0,x1):
            for y in range(y0,y1):
                yc = m*x + b
                self.framebuffer[yc][x] = color

r = Bitmap(800,600)
r.line(10,5,6,20,color(255,255,255))
r.write("outq.bmp")
